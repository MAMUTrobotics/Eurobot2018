#!/bin/bash
#

java -Xmx256m -Djava.library.path="./lib" -jar RobotLoader_lib.jar
